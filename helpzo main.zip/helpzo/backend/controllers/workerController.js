const Worker = require('../models/Worker');

// @desc    Get all workers (with optional filters)
// @route   GET /api/workers
// @access  Public
const getWorkers = async (req, res) => {
  try {
    const { category, location, search } = req.query;
    let filter = {};

    if (category && category !== 'all') {
      filter.category = category.toLowerCase();
    }

    if (location) {
      filter.location = { $regex: location, $options: 'i' };
    }

    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { category: { $regex: search, $options: 'i' } },
        { location: { $regex: search, $options: 'i' } },
      ];
    }

    const workers = await Worker.find(filter).sort({ rating: -1, createdAt: -1 });
    res.json(workers);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get single worker by ID
// @route   GET /api/workers/:id
// @access  Public
const getWorkerById = async (req, res) => {
  try {
    const worker = await Worker.findById(req.params.id);
    if (!worker) {
      return res.status(404).json({ message: 'Worker not found' });
    }
    res.json(worker);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Create a new worker profile
// @route   POST /api/workers
// @access  Private
const createWorker = async (req, res) => {
  try {
    const { name, category, location, experience, availability, phone, bio } = req.body;

    if (!name || !category || !location || experience === undefined) {
      return res.status(400).json({ message: 'Please provide all required fields' });
    }

    const worker = await Worker.create({
      name,
      category,
      location,
      experience,
      availability: availability !== undefined ? availability : true,
      phone,
      bio,
    });

    res.status(201).json(worker);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Update worker profile
// @route   PUT /api/workers/:id
// @access  Private
const updateWorker = async (req, res) => {
  try {
    const worker = await Worker.findById(req.params.id);
    if (!worker) {
      return res.status(404).json({ message: 'Worker not found' });
    }

    const updatedWorker = await Worker.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    res.json(updatedWorker);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Delete worker profile
// @route   DELETE /api/workers/:id
// @access  Private
const deleteWorker = async (req, res) => {
  try {
    const worker = await Worker.findById(req.params.id);
    if (!worker) {
      return res.status(404).json({ message: 'Worker not found' });
    }
    await worker.deleteOne();
    res.json({ message: 'Worker removed successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Seed sample workers (dev only)
// @route   POST /api/workers/seed
// @access  Public
const seedWorkers = async (req, res) => {
  try {
    await Worker.deleteMany({});

    const sampleWorkers = [
      { name: 'Carlos Rivera', category: 'plumber', location: 'Brooklyn, NY', rating: 4.8, experience: 7, availability: true, phone: '+1 (555) 123-4567', bio: 'Expert in pipe repairs, installations, and leak detection. Available 24/7 for emergencies.', reviewCount: 124 },
      { name: 'James Okonkwo', category: 'electrician', location: 'Manhattan, NY', rating: 4.9, experience: 12, availability: true, phone: '+1 (555) 234-5678', bio: 'Licensed electrician specializing in residential wiring, panel upgrades, and EV charger installation.', reviewCount: 213 },
      { name: 'Ahmed Hassan', category: 'carpenter', location: 'Queens, NY', rating: 4.6, experience: 5, availability: false, phone: '+1 (555) 345-6789', bio: 'Custom furniture maker and home renovation expert. Quality craftsmanship guaranteed.', reviewCount: 87 },
      { name: 'Mike Torres', category: 'mechanic', location: 'Bronx, NY', rating: 4.7, experience: 9, availability: true, phone: '+1 (555) 456-7890', bio: 'ASE certified mechanic. Specializing in all makes and models, diagnostics, and general repair.', reviewCount: 156 },
      { name: 'David Nguyen', category: 'painter', location: 'Staten Island, NY', rating: 4.5, experience: 6, availability: true, phone: '+1 (555) 567-8901', bio: 'Interior and exterior painting with clean, professional finish. Free estimates available.', reviewCount: 72 },
      { name: 'Sofia Patel', category: 'cleaner', location: 'Hoboken, NJ', rating: 4.9, experience: 4, availability: true, phone: '+1 (555) 678-9012', bio: 'Deep cleaning, move-in/out cleaning, and recurring home cleaning services. Eco-friendly products used.', reviewCount: 198 },
      { name: 'Luis Mendez', category: 'plumber', location: 'Jersey City, NJ', rating: 4.4, experience: 3, availability: false, phone: '+1 (555) 789-0123', bio: 'Drain cleaning, water heater installation, and bathroom remodeling specialist.', reviewCount: 43 },
      { name: 'Tom Bradley', category: 'electrician', location: 'Newark, NJ', rating: 4.6, experience: 8, availability: true, phone: '+1 (555) 890-1234', bio: 'Commercial and residential electrical services. Safety inspections and code compliance expert.', reviewCount: 91 },
      { name: 'Ravi Kumar', category: 'gardener', location: 'Brooklyn, NY', rating: 4.7, experience: 10, availability: true, phone: '+1 (555) 901-2345', bio: 'Lawn care, landscaping, tree trimming, and seasonal garden maintenance.', reviewCount: 138 },
      { name: 'Ana Ferreira', category: 'carpenter', location: 'Manhattan, NY', rating: 4.8, experience: 11, availability: true, phone: '+1 (555) 012-3456', bio: 'Kitchen and bathroom cabinet installations, hardwood flooring, and custom built-ins.', reviewCount: 177 },
    ];

    const workers = await Worker.insertMany(sampleWorkers);
    res.json({ message: `✅ Seeded ${workers.length} workers`, workers });
  } catch (error) {
    res.status(500).json({ message: 'Seed failed', error: error.message });
  }
};

module.exports = { getWorkers, getWorkerById, createWorker, updateWorker, deleteWorker, seedWorkers };
