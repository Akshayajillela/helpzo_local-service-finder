const mongoose = require('mongoose');

const workerSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      enum: ['plumber', 'electrician', 'carpenter', 'mechanic', 'painter', 'cleaner', 'gardener', 'other'],
      lowercase: true,
    },
    location: {
      type: String,
      required: [true, 'Location is required'],
      trim: true,
    },
    rating: {
      type: Number,
      default: 4.0,
      min: 0,
      max: 5,
    },
    availability: {
      type: Boolean,
      default: true,
    },
    experience: {
      type: Number, // years of experience
      required: [true, 'Experience is required'],
      min: 0,
    },
    phone: {
      type: String,
      default: '+1 (555) 000-0000',
    },
    bio: {
      type: String,
      default: '',
      maxlength: 300,
    },
    reviewCount: {
      type: Number,
      default: 0,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Worker', workerSchema);
