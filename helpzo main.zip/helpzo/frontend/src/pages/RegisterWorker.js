import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { workerAPI } from '../services/api';

const CATEGORIES = ['plumber', 'electrician', 'carpenter', 'mechanic', 'painter', 'cleaner', 'gardener', 'other'];
const CATEGORY_ICONS = {
  plumber: '🔧', electrician: '⚡', carpenter: '🪵', mechanic: '🔩',
  painter: '🎨', cleaner: '🧹', gardener: '🌿', other: '🛠️',
};

const RegisterWorker = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '', category: '', location: '', experience: '', phone: '', bio: '', availability: 'true',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.category || !form.location || !form.experience) {
      setError('Please fill in all required fields.');
      return;
    }
    setLoading(true);
    try {
      await workerAPI.create({
        ...form,
        experience: Number(form.experience),
        availability: form.availability === 'true',
      });
      setSuccess(true);
      setTimeout(() => navigate('/'), 2000);
    } catch (err) {
      if (err.response?.status === 401) {
        navigate('/login');
      } else {
        setError(err.response?.data?.message || 'Failed to create worker profile.');
      }
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4">
        <div className="text-center">
          <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="font-display font-bold text-2xl text-stone-900 mb-2">Worker Added!</h2>
          <p className="text-stone-500">Redirecting to homepage...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-10">
      <div className="mb-8">
        <h1 className="font-display font-bold text-3xl text-stone-900">Add a Worker</h1>
        <p className="text-stone-500 mt-1">Register a local service worker to the platform.</p>
      </div>

      <div className="card p-8">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-3 text-sm mb-6 flex items-center gap-2">
            <svg className="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1.5">Full Name <span className="text-red-400">*</span></label>
            <input type="text" name="name" value={form.name} onChange={handleChange} placeholder="e.g. Carlos Rivera" className="input-field" />
          </div>

          {/* Category */}
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1.5">Category <span className="text-red-400">*</span></label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => { setForm({ ...form, category: cat }); setError(''); }}
                  className={`flex flex-col items-center gap-1 p-3 rounded-xl border-2 text-sm font-medium transition-all ${
                    form.category === cat
                      ? 'border-brand-500 bg-brand-50 text-brand-700'
                      : 'border-stone-200 text-stone-600 hover:border-brand-300'
                  }`}
                >
                  <span className="text-xl">{CATEGORY_ICONS[cat]}</span>
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Location & Experience */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-stone-700 mb-1.5">Location <span className="text-red-400">*</span></label>
              <input type="text" name="location" value={form.location} onChange={handleChange} placeholder="e.g. Brooklyn, NY" className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-medium text-stone-700 mb-1.5">Experience (years) <span className="text-red-400">*</span></label>
              <input type="number" name="experience" value={form.experience} onChange={handleChange} placeholder="e.g. 5" min="0" max="50" className="input-field" />
            </div>
          </div>

          {/* Phone */}
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1.5">Phone Number</label>
            <input type="tel" name="phone" value={form.phone} onChange={handleChange} placeholder="e.g. +1 (555) 123-4567" className="input-field" />
          </div>

          {/* Availability */}
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-2">Availability</label>
            <div className="flex gap-3">
              {[{ val: 'true', label: '✅ Available', style: 'border-emerald-400 bg-emerald-50 text-emerald-700' },
                { val: 'false', label: '⏸ Not Available', style: 'border-stone-300 bg-stone-50 text-stone-600' }].map((opt) => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => setForm({ ...form, availability: opt.val })}
                  className={`flex-1 py-2.5 rounded-xl border-2 text-sm font-medium transition-all ${
                    form.availability === opt.val ? opt.style : 'border-stone-200 text-stone-500 hover:border-stone-300'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Bio */}
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1.5">Bio <span className="text-stone-400 font-normal">(optional)</span></label>
            <textarea
              name="bio"
              value={form.bio}
              onChange={handleChange}
              placeholder="A short description of services, specialties, etc."
              rows={3}
              maxLength={300}
              className="input-field resize-none"
            />
            <div className="text-right text-xs text-stone-400 mt-1">{form.bio.length}/300</div>
          </div>

          {/* Submit */}
          <button type="submit" disabled={loading} className="w-full btn-primary py-3.5 flex items-center justify-center gap-2">
            {loading ? (
              <>
                <svg className="w-4 h-4 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Adding Worker...
              </>
            ) : (
              'Add Worker Profile'
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default RegisterWorker;
