import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { workerAPI } from '../services/api';
import { CATEGORY_META, StarRating } from '../components/WorkerCard';

const WorkerProfile = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [worker, setWorker] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [contacted, setContacted] = useState(false);

  const user = JSON.parse(localStorage.getItem('helpzo_user') || 'null');

  useEffect(() => {
    const fetchWorker = async () => {
      try {
        const res = await workerAPI.getById(id);
        setWorker(res.data);
      } catch (err) {
        setError('Worker not found or server error.');
      } finally {
        setLoading(false);
      }
    };
    fetchWorker();
  }, [id]);

  const handleContact = () => {
    setContacted(true);
    setTimeout(() => setContacted(false), 3000);
  };

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-12">
        <div className="card p-8 animate-pulse">
          <div className="flex items-start gap-6 mb-8">
            <div className="w-24 h-24 rounded-2xl bg-stone-200"></div>
            <div className="flex-1">
              <div className="h-7 bg-stone-200 rounded w-1/2 mb-3"></div>
              <div className="h-4 bg-stone-100 rounded w-1/3 mb-2"></div>
              <div className="h-4 bg-stone-100 rounded w-1/4"></div>
            </div>
          </div>
          <div className="h-4 bg-stone-100 rounded w-full mb-2"></div>
          <div className="h-4 bg-stone-100 rounded w-4/5"></div>
        </div>
      </div>
    );
  }

  if (error || !worker) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <div className="text-5xl mb-4">😕</div>
        <h2 className="font-display font-bold text-xl text-stone-800 mb-2">Worker Not Found</h2>
        <p className="text-stone-500 mb-6">{error}</p>
        <Link to="/" className="btn-primary inline-flex">← Back to Home</Link>
      </div>
    );
  }

  const meta = CATEGORY_META[worker.category] || CATEGORY_META.other;

  const avatarColors = [
    'from-rose-400 to-pink-500', 'from-orange-400 to-amber-500',
    'from-teal-400 to-emerald-500', 'from-blue-400 to-cyan-500',
    'from-violet-400 to-purple-500',
  ];
  const avatarGradient = avatarColors[(worker.name?.charCodeAt(0) || 0) % avatarColors.length];

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-stone-500 mb-6">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1 hover:text-brand-600 transition-colors">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Back
        </button>
        <span>/</span>
        <span>Worker Profile</span>
      </div>

      {/* Main Card */}
      <div className="card overflow-hidden">
        {/* Top gradient banner */}
        <div className={`h-24 bg-gradient-to-r ${avatarGradient} opacity-20`}></div>

        <div className="px-6 sm:px-8 pb-8 -mt-12">
          {/* Avatar + Header */}
          <div className="flex flex-col sm:flex-row sm:items-end gap-4 mb-6">
            <div className={`w-24 h-24 rounded-2xl bg-gradient-to-br ${avatarGradient} flex items-center justify-center shadow-lg border-4 border-white flex-shrink-0`}>
              <span className="text-white font-display font-extrabold text-4xl">
                {worker.name?.charAt(0).toUpperCase()}
              </span>
            </div>

            <div className="flex-1">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h1 className="font-display font-bold text-2xl text-stone-900">{worker.name}</h1>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <div className="flex items-center gap-1">
                      <StarRating rating={worker.rating} />
                      <span className="text-sm text-stone-600 font-medium ml-1">
                        {worker.rating?.toFixed(1)}
                      </span>
                    </div>
                    <span className="text-stone-300">·</span>
                    <span className="text-sm text-stone-500">{worker.reviewCount} reviews</span>
                  </div>
                </div>

                {worker.availability ? (
                  <span className="badge-available">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    Available Now
                  </span>
                ) : (
                  <span className="badge-unavailable">
                    <span className="w-1.5 h-1.5 rounded-full bg-stone-400"></span>
                    Not Available
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Info Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6">
            <div className="bg-stone-50 rounded-xl p-4">
              <div className="text-xs text-stone-500 font-medium mb-1 uppercase tracking-wide">Category</div>
              <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-sm font-semibold border ${meta.color}`}>
                <span>{meta.icon}</span>
                {worker.category?.charAt(0).toUpperCase() + worker.category?.slice(1)}
              </div>
            </div>

            <div className="bg-stone-50 rounded-xl p-4">
              <div className="text-xs text-stone-500 font-medium mb-1 uppercase tracking-wide">Location</div>
              <div className="flex items-center gap-1.5 text-stone-800 font-medium text-sm">
                <svg className="w-4 h-4 text-brand-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                {worker.location}
              </div>
            </div>

            <div className="bg-stone-50 rounded-xl p-4">
              <div className="text-xs text-stone-500 font-medium mb-1 uppercase tracking-wide">Experience</div>
              <div className="text-stone-800 font-semibold text-sm">
                {worker.experience} year{worker.experience !== 1 ? 's' : ''}
              </div>
            </div>
          </div>

          {/* Bio */}
          {worker.bio && (
            <div className="mb-6">
              <h3 className="font-display font-bold text-stone-800 mb-2">About</h3>
              <p className="text-stone-600 leading-relaxed text-sm">{worker.bio}</p>
            </div>
          )}

          {/* Contact Actions */}
          <div className="flex flex-col sm:flex-row gap-3">
            <a
              href={`tel:${worker.phone}`}
              onClick={handleContact}
              className="flex-1 flex items-center justify-center gap-2 bg-brand-600 text-white py-3.5 rounded-xl font-semibold hover:bg-brand-700 transition-all active:scale-95 shadow-sm"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
              {contacted ? '✓ Calling...' : `Call ${worker.phone}`}
            </a>

            <button
              onClick={() => {
                if (!user) { navigate('/login'); return; }
                handleContact();
              }}
              className="flex-1 flex items-center justify-center gap-2 border-2 border-brand-200 text-brand-700 py-3.5 rounded-xl font-semibold hover:bg-brand-50 transition-all active:scale-95"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
              {contacted ? '✓ Message Sent!' : 'Send Message'}
            </button>
          </div>

          {/* Success Toast */}
          {contacted && (
            <div className="mt-4 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl px-4 py-3 text-sm flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Contact request sent! {worker.name} will get back to you shortly.
            </div>
          )}
        </div>
      </div>

      {/* Note for unauthenticated users */}
      {!user && (
        <div className="mt-4 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 text-sm text-amber-700 flex items-center gap-2">
          <svg className="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span>
            <Link to="/login" className="font-semibold underline">Sign in</Link> to send messages and save workers.
          </span>
        </div>
      )}
    </div>
  );
};

export default WorkerProfile;
